#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/wait.h>
#define port 8080
#define noreq 10

int nsfd;
void serverfunc()
{
	char buffer[80];
	int sz;
	
	while(1)
	{
	
	
		printf("enter message.....\n");
		char buffer[80]={0};
		read(0,buffer,80);
		
		 int n=strlen(buffer);
		
		send(nsfd,buffer,n,0);
		if(buffer[0]=='e'&&buffer[1]=='n'&&buffer[2]=='d')
		break;
	}

}

int main()
{
	int sfd,newsckt,valread;
	
	char address[INET_ADDRSTRLEN];
	struct sockaddr_in addr;
	int opt=1;
	int addrlen=sizeof(addr);
	
	char buf[1024]={0};
	
	char *hello="hola from server";
	
	sfd=socket(AF_INET,SOCK_STREAM,0);
	
	addr.sin_family=AF_INET;
	addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
	addr.sin_port=htons(port);
	
	bind(sfd,(struct sockaddr *)&addr,sizeof(addr));
	
	listen(sfd,noreq);
	uint16_t port2;
	printf("waiting......\n");
	
	while(1)
	{
	nsfd=accept(sfd,NULL,NULL);
		
	 
	serverfunc();
	}
	close(sfd);
	close(nsfd);
	
	
	return 0;
}
